﻿/******************************************************************************************
* Developed by Shawn Lawsure - shawnl@maine.rr.com - http://www.linkedin.com/in/shawnlawsure
* The Grid class supports the following functionality:
-> Use JSON object as the data source.
-> Row selection.
-> Row identifier (i.e. data key name).
-> Sorting by clicking on the column header (not applicable when grouping).
-> Alternate row display.
-> Scroll bars.
-> Group/display by a given group field (see below).
* Future potential enhancements:
-> Paging
-> Fixed-header when scrolling.
* Example of use:
// Use the following JSON object as the data source.
var testData = [
{ "Id": 22, "make": "Honda", "model": "CR-V", "year": "1998" },
{ "Id": 23, "make": "Toyota", "model": "Sienna", "year": "2005" },
{ "Id": 24, "make": "Nissan", "model": "Sentra", "year": "2001" },
{ "Id": 25, "make": "Toyota", "model": "Corolla", "year": "2011" },
{ "Id": 26, "make": "Ford", "model": "Focus", "year": "2008" },
{ "Id": 27, "make": "Dodge", "model": "Charger", "year": "2004" },
{ "Id": 28, "make": "Ford", "model": "Fiesta", "year": "2013" },
{ "Id": 29, "make": "Toyota", "model": "Camry", "year": "2008" },
{ "Id": 30, "make": "Dodge", "model": "Durango", "year": "2004"}];
// Call the constructor.
var myGrid = new Zenith.Grid('baseElement', testData);
// Now, set the rest of the public properties on the Grid object as necessary before
// calling the Build function.
myGrid.BindFields =
[
{ "FieldName": "make", "Header": "Make", "Width": 150 },
{ "FieldName": "model", "Header": "Model", "Width": 150 },
{ "FieldName": "year", "Header": "Year", "Width": 50 }
];
myGrid.DataKeyName = 'Id';
myGrid.PopUpControlId = 'testPopup';
myGrid.PopUpPosition = 'right';
myGrid.PopUpDirection = 'down';
myGrid.IsSelectable = true;
myGrid.IsSortable = true;
myGrid.GroupedByKeyName = 'make';
myGrid.GroupExpandImage = true;
myGrid.MaximumHeight = 100;
myGrid.OutputElementId = 'output1';
myGrid.addZenithEventListener(Zenith.ZenithEvent.EventType.Selected, function (row, rowValue, rowIndex) { alert('rowValue = ' + rowValue + ' : rowIndex = ' + rowIndex); });
myGrid.Build();
myGrid.ParentElement.className = 'gridJS';
* CSS Class Names (hard-coded) - set these in your own CSS file:
> ZenithGridTable
> ZenithGrid_HeaderRow
> ZenithGrid_SelectedRow
> ZenithGrid_AltRow
> ZenithGrid_GroupRow
> ZenithGrid_PagingFooter
> ZenithGrid_PagingControls
> ZenithGrid_PagingControlsDisabled
});
******************************************************************************************/
var __extends = this.__extends || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    __.prototype = b.prototype;
    d.prototype = new __();
};
///<reference path='ZenithControlBase.ts'/>
var Zenith;
(function (Zenith) {
    var Grid = (function (_super) {
        __extends(Grid, _super);
        // ===============  Constructor  =========================================================
        function Grid(baseDivElementId, dataSource) {
            _super.call(this, baseDivElementId);
            // The dataKeyName property is the name of the field in the JSON object that contains the
            // identifying key for each row in the data source (e.g. primary key value).  This is
            // required if you want to be able to get the key for the selected row.
            this.DataKeyName = '';
            // IsSelectable indicates that the user can select a row.  The row will be highlighted and
            // the 'selected' attribute will be set for that row.  Default is true;
            this.IsSelectable = true;
            // IsSortable indicates that the rows can be sorted by clicking on the column headers (both
            // ascending and descending).  This is not applicable when grouping by rows (see below).
            // Default is true.
            this.IsSortable = true;
            this.DefaultSortField = '';
            this.DefaultSortOrder = '';
            this.Paging = false;
            this.RowsPerPage = 10;
            //public PageForwardImage: string = '';
            //public PageBackImage: string = '';
            this.MaxPages = 10;
            // Set the GroupedByKeyName to have the grid be grouped by the given JSON object field from
            // the data source and allow the user to show and collapse the grouped rows.  When first
            // displaying the screen only the unique values for the GroupedByKeyName field will be
            // shown in the grid.  When the user clicks on one of these rows the grouped rows will be
            // displayed below the clicked row.
            this.GroupedByKeyName = '';
            // When grouping set the GroupExpandImage to true if you want to display an collapse/expand image.
            this.GroupExpandImage = false;
            this.ExpandImage = '';
            this.CollapseImage = '';
            // ===============  Private Attributes  ==================================================
            this.sortOrder = '';
            this.sortName = '';
            this.groupedFieldCellIndex = 0;
            this.pagingStartPage = 1;
            this.pagingCurrentPage = 1;
            this.DataSource = dataSource;
        }
        // ===============  Public Methods  ====================================================
        Grid.prototype.Build = function () {
            var _this = this;
            this.Clear();

            var isGrouped = this.GroupedByKeyName && this.GroupedByKeyName.length > 0;

            if (isGrouped)
                Zenith.Zenith_SortObjectsByKey(this.DataSource, this.GroupedByKeyName, "asc");
            else if (this.IsSortable) {
                if (this.sortName == '')
                    this.sortName = this.DefaultSortField;
                if (this.sortOrder == '')
                    this.sortOrder = this.DefaultSortOrder == '' ? 'asc' : this.DefaultSortOrder;

                if (this.sortName.length > 0) {
                    var sortFieldDataType = '';
                    for (var key in this.BindFields)
                        if (this.BindFields[key].FieldName == this.sortName)
                            if (this.BindFields[key].DataType)
                                sortFieldDataType = this.BindFields[key].DataType;
                    Zenith.Zenith_SortObjectsByKey(this.DataSource, this.sortName, this.sortOrder, sortFieldDataType);
                }
            }

            var th, td, trow;

            var table = document.createElement('table');
            this.BaseElement.appendChild(table);
            table.className = 'ZenithGridTable';

            this.ParentElement = table;

            var thead = document.createElement('thead');
            table.appendChild(thead);

            //==============================================================================================
            // Header row
            //==============================================================================================
            var headerRow = document.createElement('tr');
            thead.appendChild(headerRow);

            // Collapse/expand column for grouping
            if (this.GroupExpandImage) {
                th = document.createElement('th');
                headerRow.appendChild(th);
                th.style.width = '17px';
            }

            for (var key in this.BindFields) {
                var fieldName = this.BindFields[key].FieldName;
                if (fieldName) {
                    th = document.createElement('th');
                    headerRow.appendChild(th);
                    th.id = fieldName;
                    th.textContent = this.BindFields[key].Header;
                    if (this.IsSortable)
                        th.style.cursor = 'pointer';
                    if (fieldName == this.DataKeyName || (this.BindFields[key].Hidden && this.BindFields[key].Hidden == true))
                        th.style.display = 'none';
                    else {
                        if (this.IsSortable && !isGrouped)
                            th.addEventListener('click', function (event) {
                                if (_this.sortName != event.currentTarget.id)
                                    _this.sortOrder = 'asc';
                                else
                                    _this.sortOrder = _this.sortOrder == 'asc' ? 'desc' : 'asc';
                                _this.sortName = event.currentTarget.id;
                                _this.Build();
                            });

                        if (this.BindFields[key].Width)
                            th.style.width = this.BindFields[key].Width + "px";
                    }
                }
            }

            //==============================================================================================
            // Body
            //==============================================================================================
            var tbody = document.createElement('tbody');
            table.appendChild(tbody);

            var currenttbody;
            var groupRowIndex = 0;
            var inGroup = false;
            var numColumns = 0;
            var startIndex = this.Paging ? (this.pagingCurrentPage - 1) * this.RowsPerPage : 0;
            for (var index = startIndex; this.Paging ? index < startIndex + this.RowsPerPage && index < this.DataSource.length : index < this.DataSource.length; index++) {
                // The following logic is used when grouping rows.
                if (isGrouped) {
                    if (index == 0 || this.DataSource[index - 1][this.GroupedByKeyName].toUpperCase() != this.DataSource[index][this.GroupedByKeyName].toUpperCase()) {
                        groupRowIndex++;

                        currenttbody = document.createElement('tbody');
                        table.appendChild(currenttbody);

                        if (index == this.DataSource.length - 1 || this.DataSource[index][this.GroupedByKeyName].toUpperCase() != this.DataSource[index + 1][this.GroupedByKeyName].toUpperCase())
                            inGroup = false;
                        else {
                            inGroup = true;
                            var groupRow = document.createElement('tr');
                            groupRow.setAttribute('groupRow', 'true');
                            currenttbody.appendChild(groupRow);
                            groupRow.addEventListener('click', function (event) {
                                if (event.currentTarget instanceof HTMLTableRowElement) {
                                    var groupRow = event.currentTarget;
                                    var expand = true;
                                    if (groupRow.parentElement && groupRow.parentElement.nextSibling) {
                                        var nextBody = groupRow.parentElement.nextSibling;
                                        if (nextBody) {
                                            if (nextBody.style.display == 'none') {
                                                expand = true;
                                                nextBody.style.display = '';
                                            } else {
                                                expand = false;
                                                nextBody.style.display = 'none';
                                            }
                                            groupRow.setAttribute('expanded', expand ? 'true' : 'false');
                                            _this.SetRowClass();
                                        }
                                    }
                                    if (_this.GroupExpandImage) {
                                        var images = groupRow.cells[0].getElementsByTagName('img');
                                        if (expand) {
                                            images[1].style.display = 'inline';
                                            images[0].style.display = 'none';
                                        } else {
                                            images[1].style.display = 'none';
                                            images[0].style.display = 'inline';
                                        }
                                    }
                                }
                            });
                            groupRow.tabIndex = groupRowIndex;

                            if (this.GroupExpandImage) {
                                td = document.createElement('td');
                                groupRow.appendChild(td);
                                td.style.width = '17px';

                                var expandImage = document.createElement('img');
                                td.appendChild(expandImage);
                                expandImage.src = this.ExpandImage;

                                var collapseImage = document.createElement('img');
                                td.appendChild(collapseImage);
                                collapseImage.src = this.CollapseImage;
                                collapseImage.style.display = 'none';
                            }
                            groupRow.style.cursor = 'pointer';

                            for (var key in this.BindFields) {
                                var fieldName = this.BindFields[key].FieldName;
                                if (fieldName) {
                                    td = document.createElement('td');
                                    groupRow.appendChild(td);
                                    if (fieldName == this.GroupedByKeyName) {
                                        td.textContent = this.DataSource[index][fieldName];
                                        if (this.BindFields[key].Width)
                                            td.style.width = this.BindFields[key].Width + "px";
                                    }

                                    if (fieldName == this.DataKeyName || (this.BindFields[key].Hidden && this.BindFields[key].Hidden == true))
                                        td.style.display = 'none';
                                }
                            }

                            currenttbody = document.createElement('tbody');
                            table.appendChild(currenttbody);
                            currenttbody.style.display = "none";
                        }
                    }
                } else if (currenttbody == null) {
                    currenttbody = document.createElement('tbody');
                    table.appendChild(currenttbody);
                }

                // Item row
                trow = document.createElement('tr');
                currenttbody.appendChild(trow);
                trow.tabIndex = groupRowIndex;
                if (inGroup)
                    trow.setAttribute('inGroup', 'true');

                if (this.GroupExpandImage) {
                    td = document.createElement('td');
                    trow.appendChild(td);
                    td.style.width = '17px';
                }

                for (var key in this.BindFields) {
                    var fieldName = this.BindFields[key].FieldName;
                    if (fieldName) {
                        td = document.createElement('td');
                        trow.appendChild(td);
                        td.id = fieldName;
                        if (this.BindFields[key].DataType && this.BindFields[key].DataType.toUpperCase().indexOf('SHORTDATE') >= 0)
                            td.innerHTML = this.DataSource[index][fieldName] ? Zenith.DateHelper.toShortDisplayDateS(this.DataSource[index][fieldName]) : '';
                        else
                            td.innerHTML = this.DataSource[index][fieldName] ? this.DataSource[index][fieldName] : '';

                        if (fieldName == this.DataKeyName || this.BindFields[key].Hidden && this.BindFields[key].Hidden == true)
                            td.style.display = 'none';
                        else {
                            numColumns++;
                            if (this.BindFields[key].Width)
                                td.style.width = this.BindFields[key].Width + "px";
                        }
                    }
                }

                if (this.IsSelectable) {
                    trow.addEventListener('click', function (event) {
                        _this.selectedEventHandler(event);
                    });
                    trow.style.cursor = 'pointer';

                    if (this.DataKeyName.length > 0)
                        trow.setAttribute('keyValue', this.DataSource[index][this.DataKeyName]);
                }
            }

            // Paging (footer)
            var numberOfPages = Math.ceil(this.DataSource.length / this.RowsPerPage);
            if (this.Paging && numberOfPages > 1) {
                var tFoot = document.createElement('tfoot');
                table.appendChild(tFoot);

                var tRow = document.createElement('tr');
                tFoot.appendChild(tRow);

                var td = document.createElement('td');
                tRow.appendChild(td);
                td.className = 'ZenithGrid_PagingFooter';
                td.colSpan = numColumns;

                var maxPages = Math.min(numberOfPages, this.MaxPages);

                // Previous page
                var label = document.createElement('label');
                td.appendChild(label);
                label.textContent = "< Previous";
                if (this.pagingCurrentPage <= 1)
                    label.disabled = true;
                else {
                    label.style.cursor = 'pointer';
                    label.addEventListener('click', function (event) {
                        _this.pagingCurrentPage--;

                        //if (this.pagingCurrentPage < this.pagingStartPage)
                        //    this.pagingStartPage -= maxPages;
                        _this.pagingStartPage = _this.pagingCurrentPage - Math.floor(_this.MaxPages / 2);
                        _this.pagingStartPage = Math.max(_this.pagingStartPage, 1);
                        _this.Build();
                    });
                }

                label.className = label.disabled ? 'ZenithGrid_PagingControlsDisabled' : 'ZenithGrid_PagingControls';

                // First page.
                if (this.pagingStartPage > 1) {
                    label = document.createElement('label');
                    td.appendChild(label);
                    label.setAttribute('value', '1');
                    label.textContent = '1';
                    label.className = 'ZenithGrid_PagingControls';
                    label.addEventListener('click', function (event) {
                        _this.pagingCurrentPage = +event.currentTarget.getAttribute('value');
                        _this.pagingStartPage = 1;

                        _this.Build();
                    });

                    label = document.createElement('label');
                    td.appendChild(label);
                    label.textContent = '...';
                    label.style.marginLeft = "10px";
                }

                // Pages
                var pageIndex = this.pagingStartPage;
                for (; (pageIndex <= this.pagingStartPage + (maxPages - 1)) && pageIndex <= numberOfPages; pageIndex++) {
                    label = document.createElement('label');
                    td.appendChild(label);
                    label.className = 'ZenithGrid_PagingControls';

                    if (pageIndex <= numberOfPages) {
                        label.setAttribute('value', pageIndex.toString());
                        label.textContent = pageIndex.toString();
                        if (pageIndex == this.pagingCurrentPage)
                            label.style.background = 'LightGray';
                        label.addEventListener('click', function (event) {
                            _this.pagingCurrentPage = +event.currentTarget.getAttribute('value');
                            _this.pagingStartPage = _this.pagingCurrentPage - Math.floor(_this.MaxPages / 2);
                            _this.pagingStartPage = Math.max(_this.pagingStartPage, 1);
                            _this.pagingStartPage = Math.min(_this.pagingStartPage, (numberOfPages - maxPages) + 1);
                            _this.Build();
                        });
                    }
                }
                pageIndex--;

                // Last page.
                if (pageIndex < numberOfPages) {
                    label = document.createElement('label');
                    td.appendChild(label);
                    label.textContent = '...';
                    label.style.marginLeft = "10px";

                    label = document.createElement('label');
                    td.appendChild(label);
                    label.setAttribute('value', numberOfPages.toString());
                    label.textContent = numberOfPages.toString();
                    label.className = 'ZenithGrid_PagingControls';
                    label.addEventListener('click', function (event) {
                        _this.pagingCurrentPage = +event.currentTarget.getAttribute('value');
                        if (_this.pagingCurrentPage >= _this.pagingStartPage + maxPages)
                            _this.pagingStartPage = _this.pagingCurrentPage;
                        _this.pagingStartPage = Math.min(_this.pagingStartPage, (numberOfPages - maxPages) + 1);
                        _this.pagingStartPage = Math.max(_this.pagingStartPage, 1);

                        _this.Build();
                    });
                }

                // Next page
                label = document.createElement('label');
                td.appendChild(label);
                label.textContent = "Next >";
                if (this.pagingCurrentPage >= numberOfPages)
                    label.disabled = true;
                else {
                    label.style.cursor = 'pointer';
                    label.addEventListener('click', function (event) {
                        _this.pagingCurrentPage++;

                        //if (this.pagingCurrentPage >= this.pagingStartPage + maxPages)
                        //    this.pagingStartPage = this.pagingCurrentPage;
                        _this.pagingStartPage = _this.pagingCurrentPage - Math.floor(_this.MaxPages / 2);
                        _this.pagingStartPage = Math.min(_this.pagingStartPage, (numberOfPages - maxPages) + 1);
                        _this.pagingStartPage = Math.max(_this.pagingStartPage, 1);

                        _this.Build();
                    });
                }
                label.className = label.disabled ? 'ZenithGrid_PagingControlsDisabled' : 'ZenithGrid_PagingControls';
            }

            /*// Paging (footer) - with Next Set and Previous Set functionality
            if (this.Paging)
            {
            var tFoot = <HTMLTableSectionElement>document.createElement('tfoot');
            table.appendChild(tFoot);
            
            var tRow = <HTMLTableRowElement>document.createElement('tr');
            tFoot.appendChild(tRow);
            
            var td = <HTMLTableCellElement>document.createElement('td');
            tRow.appendChild(td);
            td.style.textAlign = "right";
            td.colSpan = numColumns;
            
            var numberOfPages: number = Math.ceil(this.DataSource.length / this.RowsPerPage);
            
            // Previous page
            var label = <HTMLLabelElement>document.createElement('label');
            td.appendChild(label);
            label.textContent = "< Previous";
            if (this.pagingCurrentPage <= 1)
            label.disabled = true;
            else
            label.style.cursor = 'pointer';
            label.className = label.disabled ? 'ZenithGrid_PagingControlsDisabled' : 'ZenithGrid_PagingControls';
            
            label.addEventListener('click', (event: Event) =>
            {
            this.pagingCurrentPage--;
            if (this.pagingCurrentPage < this.pagingStartPage)
            this.pagingStartPage -= maxPages;
            this.pagingStartPage = Math.max(this.pagingStartPage, 1);
            this.Build();
            });
            
            // Next page
            label = <HTMLLabelElement>document.createElement('label');
            td.appendChild(label);
            label.textContent = "Next >";
            if (this.pagingCurrentPage >= numberOfPages)
            label.disabled = true;
            else
            label.style.cursor = 'pointer';
            label.className = label.disabled ? 'ZenithGrid_PagingControlsDisabled' : 'ZenithGrid_PagingControls';
            label.addEventListener('click', (event: Event) =>
            {
            this.pagingCurrentPage++;
            if (this.pagingCurrentPage >= this.pagingStartPage + maxPages)
            this.pagingStartPage = this.pagingCurrentPage;
            this.pagingStartPage = Math.min(this.pagingStartPage, (numberOfPages - maxPages) + 1);
            
            this.Build();
            });
            
            for (var index = this.pagingStartPage; index <= this.pagingStartPage + (maxPages - 1); index++)
            {
            label = <HTMLLabelElement>document.createElement('label');
            td.appendChild(label);
            label.className = 'ZenithGrid_PagingControls';
            
            if (index <= numberOfPages)
            {
            label.setAttribute('value', index.toString());
            label.textContent = index.toString();
            if (index == this.pagingCurrentPage)
            label.style.background = 'LightGray';
            
            label.addEventListener('click', (event: Event) =>
            {
            this.pagingCurrentPage = +(<HTMLElement>event.currentTarget).getAttribute('value');
            this.Build();
            });
            }
            }
            
            // Previous set
            var image = <HTMLImageElement>document.createElement('img');
            td.appendChild(image);
            image.src = this.PageBackImage;
            image.width = 15;
            image.height = 15;
            image.style.marginLeft = "10px";
            if (this.pagingStartPage <= 1)
            image.disabled = true;
            else
            image.style.cursor = 'pointer';
            image.addEventListener('click', (event: Event) =>
            {
            this.pagingStartPage = this.pagingStartPage - maxPages;
            this.pagingStartPage = Math.max(this.pagingStartPage, 1);
            this.pagingCurrentPage = this.pagingStartPage;
            this.Build();
            });
            
            // Next set
            image = <HTMLImageElement>document.createElement('img');
            td.appendChild(image);
            image.src = this.PageForwardImage;
            image.width = 15;
            image.height = 15;
            image.style.marginLeft = "10px";
            if (this.pagingStartPage + maxPages > numberOfPages)
            image.disabled = true;
            else
            image.style.cursor = 'pointer';
            image.addEventListener('click', (event: Event) =>
            {
            this.pagingStartPage = this.pagingStartPage + maxPages;
            this.pagingStartPage = Math.min(this.pagingStartPage, (numberOfPages - maxPages) + 1);
            this.pagingCurrentPage = this.pagingStartPage;
            this.Build();
            });
            }*/
            //table.style.cursor = this.IsSelectable ? 'pointer' : "";
            this.SetRowClass();

            if (this.IsPopup())
                _super.prototype.SetPopup.call(this);

            _super.prototype.Build.call(this);
        };

        // ===============  Private Methods  ====================================================
        Grid.prototype.SetRowClass = function (selectedRow) {
            var rows = this.ParentElement.getElementsByTagName('tr');
            for (var index = 0; index < rows.length; index++) {
                var row = rows[index];

                if (this.IsSelectable && selectedRow)
                    row.setAttribute('selected', selectedRow == row ? 'true' : 'false');

                if (index == 0)
                    row.className = 'ZenithGrid_HeaderRow';
                else if (this.IsSelectable && row.attributes['selected'] && row.attributes['selected'].value == 'true')
                    row.className = 'ZenithGrid_SelectedRow';
                else if ((row.attributes['inGroup'] && row.attributes['inGroup'].value == 'true') || (row.attributes['groupRow'] && row.attributes['groupRow'].value == 'true' && row.attributes['expanded'] && row.attributes['expanded'].value == 'true'))
                    row.className = 'ZenithGrid_GroupRow';
                else if (index % 2 == 0)
                    row.className = 'ZenithGrid_AltRow';
                else
                    row.className = 'ZenithGrid_UnselectedRow';

                if (this.Paging && index == rows.length - 1)
                    row.className = '';
            }
        };

        // ===============  Event Handlers  ====================================================
        Grid.prototype.selectedEventHandler = function (event) {
            var trow = event.currentTarget;
            this.SetRowClass(trow);

            this.SetOutput(trow.getAttribute('keyValue'));

            if (this.IsSelectable)
                _super.prototype.ExecuteEvent.call(this, Zenith.ZenithEvent.EventType.Selected, [event.currentTarget, trow.getAttribute('keyValue'), trow.rowIndex]);

            if (this.IsPopup())
                _super.prototype.Close.call(this);
        };
        return Grid;
    })(Zenith.ControlBase);
    Zenith.Grid = Grid;
})(Zenith || (Zenith = {}));
